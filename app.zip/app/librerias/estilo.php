<script src="<?php echo RUTA_ESTILOS; ?>/js/jquery-3.2.1.min.js"></script>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo RUTA_ESTILOS; ?>/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bbootstrap 4 -->
  <link rel="stylesheet" href="<?php echo RUTA_ESTILOS; ?>/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="<?php echo RUTA_ESTILOS; ?>/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- JQVMap -->
  <link rel="stylesheet" href="<?php echo RUTA_ESTILOS; ?>/plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo RUTA_ESTILOS; ?>/dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="<?php echo RUTA_ESTILOS; ?>/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="<?php echo RUTA_ESTILOS; ?>/plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="<?php echo RUTA_ESTILOS; ?>/plugins/summernote/summernote-bs4.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <!--Notify -->
 

 <!-- Pagina de prueba -->
 <link href="<?php echo RUTA_ESTILOS; ?>/pagina_prueba/assets/img/favicon.png" rel="icon">
  <link href="<?php echo RUTA_ESTILOS; ?>/pagina_prueba/assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?php echo RUTA_ESTILOS; ?>/pagina_prueba/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo RUTA_ESTILOS; ?>/pagina_prueba/assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="<?php echo RUTA_ESTILOS; ?>/pagina_prueba/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="<?php echo RUTA_ESTILOS; ?>/pagina_prueba/assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="<?php echo RUTA_ESTILOS; ?>/pagina_prueba/assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="<?php echo RUTA_ESTILOS; ?>/pagina_prueba/assets/css/style.css" rel="stylesheet">

 <!-- Fin Pagina de prueba -->




 <script src="<?php echo RUTA_ESTILOS; ?>/plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?php echo RUTA_ESTILOS; ?>/plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="<?php echo RUTA_ESTILOS; ?>/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS -->
<script src="<?php echo RUTA_ESTILOS; ?>/plugins/chart.js/Chart.min.js"></script>
<!-- Sparkline -->
<script src="<?php echo RUTA_ESTILOS; ?>/plugins/sparklines/sparkline.js"></script>
<!-- JQVMap -->
<script src="<?php echo RUTA_ESTILOS; ?>/plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="<?php echo RUTA_ESTILOS; ?>/plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<!-- jQuery Knob Chart -->
<script src="<?php echo RUTA_ESTILOS; ?>/plugins/jquery-knob/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="<?php echo RUTA_ESTILOS; ?>/plugins/moment/moment.min.js"></script>
<script src="<?php echo RUTA_ESTILOS; ?>/plugins/daterangepicker/daterangepicker.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="<?php echo RUTA_ESTILOS; ?>/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Summernote -->
<script src="<?php echo RUTA_ESTILOS; ?>/plugins/summernote/summernote-bs4.min.js"></script>
<!-- overlayScrollbars -->
<script src="<?php echo RUTA_ESTILOS; ?>/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo RUTA_ESTILOS; ?>/dist/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="<?php echo RUTA_ESTILOS; ?>/dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo RUTA_ESTILOS; ?>/dist/js/demo.js"></script>
<script type="text/javascript" src="<?php echo RUTA_URL; ?>/publico/js/main.js"></script>
<script src="<?php echo RUTA_ESTILOS; ?>/js/notify.js" type="text/javascript"></script>
