<?php
require_once 'config/configurar.php';

//AUTOLOAD carga las librerias de la carpeta librerias
require_once 'librerias/Base.php';
require_once 'librerias/Controlador.php';
require_once 'librerias/Core.php';
require_once 'helpers/url_helper.php';

//spl_autoload_register(function($nombreClase){
 //require_once 'librerias/'.$nombreClase.'.php';
//});


?>
