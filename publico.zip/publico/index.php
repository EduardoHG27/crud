<?php
//cargar iniciador.php de la carpeta app
require_once '../app/iniciador.php';

//instanciar la clase controlador
    $iniciar= new Core;
?>